package com.demo.services;

import java.util.List;


import com.demo.entity.Location;



public interface LocationService {
	//01. Add New Hostel
		public String addLocation(Location hstl);

	//02. Get Location Details By Their ID
		public Location getLocationDetail(int id);

	//03. Update Location Details
		public String updateLocationDetails(int id, Location hstl);

	//04. Delete location By ID
		public String deleteLocation(int id);

	//05. Add Multiple New Location
		public String saveAll(List<Location> hstl);

	//06. Show All Location
		public List<Location> showAll();

	//07. Delete All Location
		public String clearAll();
	

}
