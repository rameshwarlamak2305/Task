package com.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.demo.entity.Location;
import com.demo.repository.LocationRespo;

import lombok.Data;
@Data
@Service
public class LocationServiceImp implements LocationService {
	@Autowired
	private LocationRespo locationrepository;
	@Override
	public String addLocation(Location hstl) {
		locationrepository.save(hstl);
		return "New Hostel ID " + hstl.getId() + " Added Successfully";
	}

	@Override
	public Location getLocationDetail(int id) {
		
		Optional<Location> findById = locationrepository.findById(id);
		return findById.get();
	}

	
		
		
	

	@Override
	public String deleteLocation(int id) {
		
		locationrepository.deleteById(id);
		return "Location ID " + id + " Deleted Successfully";
	}

	@Override
	public String saveAll(List<Location> hstl) {
		
		locationrepository.saveAll(hstl);
		return hstl.size() + " Hostels Details Are Added Successfully";
	}

	@Override
	public List<Location> showAll() {
		
		return locationrepository.findAll();
	}

	@Override
	public String clearAll() {
	
		List<Location> findAll =locationrepository.findAll();
		locationrepository.deleteAll(findAll);
		return "All " + findAll.size() + " Records Are Deleted Successfully";
	}

	@Override
	public String updateLocationDetails(int id, Location hstl) {
		// TODO Auto-generated method stub
		return null;
	}

}
