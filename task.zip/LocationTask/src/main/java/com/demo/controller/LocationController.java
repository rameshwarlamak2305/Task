package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Location;
import com.demo.services.LocationService;

import lombok.Data;

@Data
@RestController
public class LocationController {
	@Autowired
	private LocationService locationService;
	
	//01. Adding New Hostels
		@PostMapping("/add")
		public String addHostel(@RequestBody Location hstl) {
			return locationService.addLocation(hstl);
		}

	//Get Hostels By Their ID
		@GetMapping("/get/{id}")
		public Location getLocationDetails(@PathVariable int id) {
			return locationService.getLocationDetail(id);
		}

		@PutMapping("/update/{id}")
		public String updateLocationDetails(@PathVariable int id, @RequestBody Location hstl) {
			return locationService.updateLocationDetails(id, hstl);
		}

		@DeleteMapping("/delete/{id}")
		public String deleteLocation(@PathVariable int id) {
			return locationService.deleteLocation(id);
		}

		@GetMapping("/showAll")
		public List<Location> showAll() {
			return locationService.showAll();
		}

		@PostMapping("/saveAll")
		public String saveAll(@RequestBody List<Location> std) {
			return locationService.saveAll(std);
		}

		@DeleteMapping("/clearAll")
		public String deleteAll() {
			return locationService.clearAll();
		}
	

}
